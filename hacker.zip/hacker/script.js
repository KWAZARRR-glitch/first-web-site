
document.addEventListener('DOMContentLoaded', function() {

    
    const button = document.getElementById('myButton');button.addEventListener('click', function() {
       
        alert('Ура! Вы нажали на кнопку! JavaScript работает!');

      
    
    });

});